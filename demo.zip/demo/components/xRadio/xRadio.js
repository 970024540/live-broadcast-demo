Component({
  data:{
    items: [
      {value: 'success', label: '绿色',checked: 'true'},
      {value: 'warning', label: '橙色'},
      {value: 'danger', label: '红色'},
      {value: 'purple', label: '紫色'},
      {value: 'white', label: '白色'},
      {value: 'black', label: '黑色'},
    ]
  }
})
