import {slogan} from '../../config/index.js';

Component({
  options: {
    addGlobalClass: true
  },
  properties:{

  },
  data:{
    slogan:slogan
  }
})
