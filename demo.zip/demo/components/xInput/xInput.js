Component({
  options: {
    addGlobalClass: true
  },
  properties:{
    title:{
      type:String,
      value:'',
    },
    value:{
      type:String,
      value:''
    },
    placeholder:{
      type:String,
      value:''
    }
  }
})
