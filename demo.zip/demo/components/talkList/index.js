Component({
  properties: {
    currentChatList:{
      type:Array,
      value:[]
    },
    localUserId:{
      type:String,
      value:'183073'
    }
  }
})