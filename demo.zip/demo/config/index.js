export const slogan="©影儿时尚集团";
export const activeTheme="white";
export const theme={
  white:{
    color:'color-dark',
    backgroundColor:"bg-white",
    activeColor:'color-success',
    activeBg:'bg-success'
  },
  success:{
    color:'color-white',
    backgroundColor:"bg-success",
    activeColor:'color-white',
    activeBg:'bg-white'
  }
};
export const brand2PageId={
  "yi":'2',
  "in":'4',
  "ps":'3',
  "sos":'5',
  "obb":'11',
  "xii":'6',
  "音儿蓝标":'7',
  "恩裳蓝标":'9',
  "诗篇蓝标":'8',
  "十二篮蓝标":'10',
  "美妆":"12",
  "mettler":'13',
}
export const dogBrand = 'https://mall.yingerfashion.com/yinger-m/img/logo_dog.png';
